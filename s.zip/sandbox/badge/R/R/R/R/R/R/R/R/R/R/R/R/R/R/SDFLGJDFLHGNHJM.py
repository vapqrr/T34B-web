print(f'''
lol
''')
